import bpy
from .utils import _gp_obj, _next_frame, _prev_frame, _drawing_of_frame, _copy_geometry, _redraw

class SO_OT_copy_from_neighbor(bpy.types.Operator):
    bl_idname = "stroke_organiser.copy_from_neighbor"
    bl_label = "Copier depuis frame voisine"
    bl_options = {'REGISTER', 'UNDO'}
    direction: bpy.props.EnumProperty(name="Direction", items=[('PREV', "← Précédente", ""), ('NEXT', "→ Suivante", "")], default='PREV')

    @classmethod
    def poll(cls, context):
        from .utils import _as
        obj = _gp_obj(context)
        return obj and context.mode in {'EDIT_GREASE_PENCIL', 'EDIT'} and not getattr(_as, 'active', False)

    def execute(self, context):
        obj = _gp_obj(context)
        if not obj or not obj.data.layers.active:
            return {'CANCELLED'}
        
        layer = obj.data.layers.active
        frame = layer.current_frame()
        if not frame:
            return {'CANCELLED'}
            
        drawing = getattr(frame, 'drawing', None)
        if not drawing or not hasattr(drawing, 'strokes'):
            return {'CANCELLED'}
        
        # --- CORRECTION : DÉTECTION MULTI-SÉLECTION ROBUSTE ---
        selected_indices = []
        for si, stroke in enumerate(drawing.strokes):
            is_sel = False
            
            # 1. Vérification globale sur le stroke
            if getattr(stroke, 'select', False):
                is_sel = True
            
            # 2. Vérification granulaire sur chaque point (fallback indispensable)
            if not is_sel:
                try:
                    if hasattr(stroke, 'points'):
                        for p in stroke.points:
                            if getattr(p, 'select', False):
                                is_sel = True
                                break
                except AttributeError:
                    pass
            
            if is_sel:
                selected_indices.append(si)
        # ------------------------------------------------------
                
        if not selected_indices:
            self.report({'WARNING'}, "Aucun stroke sélectionné. Assurez-vous d'avoir sélectionné les tracés dans le calque actif.")
            return {'CANCELLED'}
        
        neighbor = _prev_frame(obj) if self.direction == 'PREV' else _next_frame(obj)
        if neighbor is None: 
            self.report({'WARNING'}, "Aucune frame voisine trouvée.")
            return {'CANCELLED'}
        
        src_d = _drawing_of_frame(neighbor)
        if src_d is None: 
            return {'CANCELLED'}
        
        copied_count = 0
        for si in selected_indices:
            # Sécurité pour éviter les crashs si le nombre de strokes diffère
            if si >= len(src_d.strokes) or si >= len(drawing.strokes):
                continue
                
            src = src_d.strokes[si]
            dst = drawing.strokes[si]
            
            if len(src.points) == 0: 
                continue
            
            _copy_geometry(src, dst)
            copied_count += 1
            
        if copied_count > 0:
            obj.data.update_tag()
            _redraw()
            self.report({'INFO'}, f"{copied_count} stroke(s) copié(s) avec succès.")
            return {'FINISHED'}
            
        self.report({'WARNING'}, "La copie a échoué (les index des strokes cibles n'existent peut-être pas sur la frame voisine).")
        return {'CANCELLED'}


class SO_OT_create_vertex_groups(bpy.types.Operator):
    bl_idname = "stroke_organiser.create_vertex_groups"
    bl_label = "Créer Vertex Groups"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = _gp_obj(context)
        props = getattr(context.scene, 'stroke_organiser_props', None)
        return obj and props and props.armature_target is not None

    def execute(self, context):
        obj = _gp_obj(context)
        props = context.scene.stroke_organiser_props
        armature = props.armature_target
        
        if not obj or not armature:
            self.report({'ERROR'}, "Objet GP ou armature cible manquant.")
            return {'CANCELLED'}
        
        if armature.type != 'ARMATURE':
            self.report({'ERROR'}, "La cible n'est pas une armature.")
            return {'CANCELLED'}
        
        # Récupérer tous les bones de l'armature
        bone_names = [bone.name for bone in armature.data.bones]
        
        if not bone_names:
            self.report({'WARNING'}, "L'armature n'a pas de bones.")
            return {'CANCELLED'}
        
        # Créer les vertex groups manquants
        created_count = 0
        existing_groups = {vg.name for vg in obj.vertex_groups}
        
        for bone_name in bone_names:
            if bone_name not in existing_groups:
                obj.vertex_groups.new(name=bone_name)
                created_count += 1
        
        if created_count > 0:
            self.report({'INFO'}, f"{created_count} vertex group(s) créé(s).")
        else:
            self.report({'INFO'}, "Tous les vertex groups existent déjà.")
        
        return {'FINISHED'}
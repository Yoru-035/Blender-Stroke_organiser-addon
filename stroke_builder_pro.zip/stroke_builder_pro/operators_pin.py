import bpy
import traceback
from mathutils import Vector
from .utils import _gp_obj, _get_drawing, _get_pt_pos, _set_pt_pos

class SO_OT_catmull_corner(bpy.types.Operator):
    bl_idname = "stroke_organiser.catmull_corner"
    bl_label = "Subdiviser 3 points"
    bl_description = "Subdivise exactement 3 points adjacents pour créer 5 points, préparant un angle modifiable manuellement"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = _gp_obj(context)
        return obj and context.mode in {'EDIT_GREASE_PENCIL', 'EDIT'}

    def execute(self, context):
        obj = _gp_obj(context)
        if not obj:
            return {'CANCELLED'}

        old_mode = obj.mode
        
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        drawing = _get_drawing(obj)
        if not drawing or not drawing.strokes:
            if old_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=old_mode)
            self.report({'WARNING'}, "Aucun tracé trouvé dans la frame active.")
            return {'CANCELLED'}

        strokes_to_replace = []
        modified_any = False

        for s_idx, stroke in enumerate(drawing.strokes):
            try:
                sel_indices = [i for i, p in enumerate(stroke.points) if getattr(p, 'select', False)]
            except Exception:
                continue
            
            if not sel_indices:
                continue

            if len(sel_indices) != 3:
                self.report({'WARNING'}, f"Tracé ignoré : Il faut exactement 3 points sélectionnés (trouvé {len(sel_indices)}).")
                continue

            i1, i2, i3 = sel_indices
            
            if not ((i2 == i1 + 1) and (i3 == i2 + 1)):
                self.report({'WARNING'}, "Tracé ignoré : Les 3 points sélectionnés doivent être adjacents.")
                continue

            orig_points = []
            for p in stroke.points:
                # Récupération adaptative (Blender 5.0 utilise .radius et .opacity)
                orig_points.append({
                    'co': Vector(_get_pt_pos(p)),
                    'radius': getattr(p, 'radius', getattr(p, 'pressure', 1.0)),
                    'opacity': getattr(p, 'opacity', getattr(p, 'strength', 1.0)),
                    'select': getattr(p, 'select', False)
                })

            new_points = []
            
            # Subdivision topologique avec conservation et lissage des attributs
            for i, p_orig in enumerate(orig_points):
                if i == i1:
                    p_copy = p_orig.copy()
                    p_copy['select'] = False
                    new_points.append(p_copy)
                    
                    p_next = orig_points[i2]
                    new_points.append({
                        'co': (p_orig['co'] + p_next['co']) * 0.5,
                        'radius': (p_orig['radius'] + p_next['radius']) * 0.5,
                        'opacity': (p_orig['opacity'] + p_next['opacity']) * 0.5,
                        'select': True
                    })
                elif i == i2:
                    p_copy = p_orig.copy()
                    p_copy['select'] = True
                    new_points.append(p_copy)
                    
                    p_next = orig_points[i3]
                    new_points.append({
                        'co': (p_orig['co'] + p_next['co']) * 0.5,
                        'radius': (p_orig['radius'] + p_next['radius']) * 0.5,
                        'opacity': (p_orig['opacity'] + p_next['opacity']) * 0.5,
                        'select': True
                    })
                elif i == i3:
                    p_copy = p_orig.copy()
                    p_copy['select'] = False
                    new_points.append(p_copy)
                else:
                    new_points.append(p_orig)

            strokes_to_replace.append({
                'orig_idx': s_idx,
                'new_points': new_points,
                'cyclic': stroke.cyclic,
                'material_index': stroke.material_index
            })
            modified_any = True

        if not modified_any:
            if old_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=old_mode)
            return {'CANCELLED'}

        try:
            for item in strokes_to_replace:
                pts = item['new_points']
                drawing.add_strokes([len(pts)])
                
                new_stroke = drawing.strokes[-1]
                new_stroke.cyclic = item['cyclic']
                new_stroke.material_index = item['material_index']

                for idx, pt_data in enumerate(pts):
                    gp_pt = new_stroke.points[idx]
                    _set_pt_pos(gp_pt, pt_data['co'])
                    
                    # Application de l'épaisseur (Radius GPv3)
                    if hasattr(gp_pt, 'radius'):
                        gp_pt.radius = pt_data['radius']
                    elif hasattr(gp_pt, 'pressure'):
                        gp_pt.pressure = pt_data['radius']
                        
                    # Application de la transparence (Opacity GPv3)
                    if hasattr(gp_pt, 'opacity'):
                        gp_pt.opacity = pt_data['opacity']
                    elif hasattr(gp_pt, 'strength'):
                        gp_pt.strength = pt_data['opacity']
                        
                    if hasattr(gp_pt, 'select'):
                        gp_pt.select = pt_data['select']

            # Suppression des anciens tracés
            old_indices = sorted([item['orig_idx'] for item in strokes_to_replace], reverse=True)
            drawing.remove_strokes(indices=old_indices)

            # Application du type CATMULL_ROM
            num_new = len(strokes_to_replace)
            total_strokes = len(drawing.strokes)
            shifted_new_indices = list(range(total_strokes - num_new, total_strokes))
            drawing.set_types(type='CATMULL_ROM', indices=shifted_new_indices)

            if hasattr(drawing, "tag_positions_changed"):
                drawing.tag_positions_changed()
            obj.data.update_tag()
            
        except Exception as e:
            traceback.print_exc()
            self.report({'ERROR'}, f"Erreur lors de la subdivision : {str(e)}")
            if old_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=old_mode)
            return {'CANCELLED'}

        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode=old_mode)
            
        context.view_layer.update()
        return {'FINISHED'}
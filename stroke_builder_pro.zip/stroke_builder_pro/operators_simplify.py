import bpy
import math
import traceback
from mathutils import Vector
from bpy.props import FloatProperty, BoolProperty
from bpy.types import Operator

def compute_turn_angles(pos, cyclic):
    n = len(pos)
    angles = [0.0] * n
    for i in range(n):
        if not cyclic and (i == 0 or i == n - 1):
            angles[i] = 0.0
            continue
        ip = (i - 1) % n
        inx = (i + 1) % n
        v1 = pos[i] - pos[ip]
        v2 = pos[inx] - pos[i]
        l1 = v1.length
        l2 = v2.length
        if l1 < 1e-9 or l2 < 1e-9:
            angles[i] = 0.0
            continue
        d = v1.normalized().dot(v2.normalized())
        d = max(-1.0, min(1.0, d))
        angles[i] = math.acos(d)
    return angles

def indices_between(idx, next_idx, n, cyclic):
    if not cyclic:
        return list(range(idx + 1, next_idx))
    if next_idx > idx:
        return list(range(idx + 1, next_idx))
    return list(range(idx + 1, n)) + list(range(0, next_idx))

def select_interior_points(sub_indices, angles, k):
    if k <= 0 or not sub_indices:
        return []
    if k >= len(sub_indices):
        return list(sub_indices)

    weights = [angles[i] for i in sub_indices]
    total = sum(weights)

    if total <= 1e-9:
        step = len(sub_indices) / (k + 1)
        picks = []
        for j in range(1, k + 1):
            i = int(round(step * j)) - 1
            i = max(0, min(len(sub_indices) - 1, i))
            picks.append(sub_indices[i])
        return sorted(set(picks), key=lambda idx: sub_indices.index(idx))

    cum = []
    running = 0.0
    for w in weights:
        running += w
        cum.append(running)

    picks = []
    for j in range(1, k + 1):
        target = total * j / (k + 1)
        best_i = min(range(len(sub_indices)), key=lambda ii: abs(cum[ii] - target))
        picks.append(sub_indices[best_i])

    return sorted(set(picks), key=lambda idx: sub_indices.index(idx))

def lerp_float(a, b, t):
    return a + (b - a) * t

def lerp_point(pA, pB, t):
    vcA = pA.get('vertex_color', (0.0, 0.0, 0.0, 0.0))
    vcB = pB.get('vertex_color', (0.0, 0.0, 0.0, 0.0))
    vc = tuple(lerp_float(vcA[i], vcB[i], t) for i in range(len(vcA)))
    return {
        'pos': pA['pos'].lerp(pB['pos'], t),
        'radius': lerp_float(pA['radius'], pB['radius'], t),
        'opacity': lerp_float(pA['opacity'], pB['opacity'], t),
        'rotation': lerp_float(pA.get('rotation', 0.0), pB.get('rotation', 0.0), t),
        'vertex_color': vc,
        'select': pA.get('select', False),
    }

def make_flat_nudge(points_data, pos, idx, prev_orig, next_orig, nudge_base):
    dir_in = pos[idx] - pos[prev_orig]
    dir_out = pos[next_orig] - pos[idx]
    if dir_in.length < 1e-9 or dir_out.length < 1e-9:
        return None
    din = dir_in.normalized()
    dout = dir_out.normalized()
    bis = -(din + dout)
    if bis.length < 1e-5:
        helper = Vector((1.0, 0.0, 0.0)) if abs(din.x) < 0.9 else Vector((0.0, 1.0, 0.0))
        perp = din.cross(helper)
        if perp.length < 1e-6:
            perp = Vector((0.0, 0.0, 1.0))
        bis = perp.normalized()
    else:
        bis = bis.normalized()
    nd = max(1e-5, nudge_base * 0.15)
    data = dict(points_data[idx])
    data['pos'] = pos[idx] + bis * nd
    return data

def dedupe_consecutive(points, cyclic, eps=1e-7):
    if not points:
        return points
    out = [points[0]]
    for p in points[1:]:
        if (p['pos'] - out[-1]['pos']).length > eps:
            out.append(p)
    if cyclic and len(out) > 1 and (out[0]['pos'] - out[-1]['pos']).length <= eps:
        out.pop()
    return out

def build_catmull_points(points, cyclic, angle_thr, cusp_thr, curvature_step):
    n = len(points)
    pos = [p['pos'] for p in points]
    angles = compute_turn_angles(pos, cyclic)

    if cyclic:
        anchors = sorted(i for i in range(n) if angles[i] >= angle_thr)
        if not anchors:
            anchors = [max(range(n), key=lambda i: angles[i])]
    else:
        anchors = sorted(set([0, n - 1] + [i for i in range(1, n - 1) if angles[i] >= angle_thr]))

    m = len(anchors)
    if m < 2 and not cyclic:
        anchors = [0, n - 1]
        m = 2

    output = []

    for k, idx in enumerate(anchors):
        ang = angles[idx]
        if ang >= angle_thr:
            prev_orig = (idx - 1) % n if cyclic else idx - 1
            next_orig = (idx + 1) % n if cyclic else idx + 1

            if 0 <= prev_orig < n and 0 <= next_orig < n:
                kept_prev_idx = anchors[k - 1]
                kept_next_idx = anchors[(k + 1) % m] if cyclic else anchors[min(k + 1, m - 1)]

                d_to_prev_kept = (pos[idx] - pos[kept_prev_idx]).length
                d_to_next_kept = (pos[idx] - pos[kept_next_idx]).length
                d_prev_orig = (pos[idx] - pos[prev_orig]).length
                d_next_orig = (pos[idx] - pos[next_orig]).length

                pin_dist_a = d_prev_orig
                pin_dist_b = d_next_orig
                if d_to_prev_kept > 1e-9:
                    pin_dist_a = min(pin_dist_a, 0.45 * d_to_prev_kept)
                if d_to_next_kept > 1e-9:
                    pin_dist_b = min(pin_dist_b, 0.45 * d_to_next_kept)

                if (pin_dist_a > 1e-9 and d_prev_orig > 1e-9
                        and pin_dist_b > 1e-9 and d_next_orig > 1e-9):
                    s = pin_dist_a / d_prev_orig
                    t = pin_dist_b / d_next_orig
                    pin_a = lerp_point(points[idx], points[prev_orig], s)
                    pin_b = lerp_point(points[idx], points[next_orig], t)

                    output.append(pin_a)
                    output.append(points[idx])
                    if ang >= cusp_thr:
                        flat_pt = make_flat_nudge(
                            points, pos, idx, prev_orig, next_orig,
                            min(pin_dist_a, pin_dist_b)
                        )
                        if flat_pt is not None:
                            output.append(flat_pt)
                    output.append(pin_b)
                else:
                    output.append(points[idx])
            else:
                output.append(points[idx])
        else:
            output.append(points[idx])

        if k < m - 1 or cyclic:
            next_k = (k + 1) % m
            next_idx = anchors[next_k]
            sub_indices = indices_between(idx, next_idx, n, cyclic)
            if sub_indices:
                total_turn = sum(angles[i] for i in sub_indices)
                k_interior = max(0, round(total_turn / curvature_step) - 1)
                k_interior = min(k_interior, len(sub_indices))
                interior = select_interior_points(sub_indices, angles, k_interior)
                for ii in interior:
                    output.append(points[ii])

    output = dedupe_consecutive(output, cyclic)
    return output

def get_active_drawing(obj):
    gp = obj.data
    layer = gp.layers.active
    if layer is None:
        return None, "Aucun calque Grease Pencil actif."
    frame = layer.current_frame()
    if frame is None:
        return None, "Aucune image (frame) active sur ce calque."
    return frame.drawing, None

def extract_point_data(stroke):
    pts = []
    for p in stroke.points:
        pts.append({
            'pos': Vector(p.position),
            'radius': p.radius,
            'opacity': p.opacity,
            'rotation': getattr(p, 'rotation', 0.0),
            'vertex_color': tuple(p.vertex_color) if hasattr(p, 'vertex_color') else (0.0, 0.0, 0.0, 0.0),
            'select': bool(getattr(p, 'select', False)),
        })
    return pts

def is_stroke_selected(stroke):
    try:
        if stroke.select:
            return True
    except Exception:
        pass
    try:
        for p in stroke.points:
            if p.select:
                return True
    except Exception:
        pass
    return False

def apply_points_to_stroke(drawing, stroke_index, new_points):
    stroke = drawing.strokes[stroke_index]
    old_n = len(stroke.points)
    new_n = len(new_points)
    delta = new_n - old_n
    if delta > 0:
        stroke.add_points(delta)
    elif delta < 0:
        stroke.remove_points(-delta)

    stroke = drawing.strokes[stroke_index]
    for i, data in enumerate(new_points):
        pt = stroke.points[i]
        pt.position = data['pos']
        pt.radius = data['radius']
        pt.opacity = data['opacity']
        try:
            pt.rotation = data['rotation']
        except Exception:
            pass
        try:
            pt.vertex_color = data['vertex_color']
        except Exception:
            pass
        try:
            pt.select = data['select']
        except Exception:
            pass

class GP_OT_catmull_smart_simplify(Operator):
    bl_idname = "gpencil.catmull_rom_smart_simplify"
    bl_label = "Convertir en Catmull-Rom"
    bl_description = "Convertit le(s) stroke(s) en Catmull-Rom"
    bl_options = {'REGISTER', 'UNDO'}

    angle_threshold: FloatProperty(
        name="Seuil d'angle",
        default=math.radians(35.0),
        min=math.radians(1.0),
        max=math.radians(179.0),
        subtype='ANGLE',
    )
    cusp_angle: FloatProperty(
        name="Seuil de pointe aigue",
        default=math.radians(150.0),
        min=math.radians(90.0),
        max=math.radians(179.9),
        subtype='ANGLE',
    )
    curvature_step: FloatProperty(
        name="Pas de courbure",
        default=math.radians(45.0),
        min=math.radians(5.0),
        max=math.radians(180.0),
        subtype='ANGLE',
    )
    only_poly: BoolProperty(
        name="Uniquement les strokes POLY",
        default=False,
    )
    only_selected: BoolProperty(
        name="Uniquement les strokes selectionnes",
        default=True,
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == 'GREASEPENCIL' and obj.data is not None)

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.label(text="Detection des angles :")
        col.prop(self, "angle_threshold")
        col.prop(self, "cusp_angle")
        col.separator()
        col.label(text="Densite dans les arcs :")
        col.prop(self, "curvature_step")
        col.separator()
        col.prop(self, "only_selected")
        col.prop(self, "only_poly")

    def execute(self, context):
        obj = context.active_object
        try:
            drawing, err = get_active_drawing(obj)
            if drawing is None:
                self.report({'ERROR'}, err)
                return {'CANCELLED'}

            in_edit = obj.mode == 'EDIT'
            restrict_selected = in_edit and self.only_selected

            stroke_count = len(drawing.strokes)
            skipped_not_poly = 0
            skipped_not_selected = 0
            skipped_too_short = 0
            curve_types_seen = set()
            targets = []
            for si in range(stroke_count):
                stroke = drawing.strokes[si]
                curve_types_seen.add(stroke.curve_type)
                if self.only_poly and stroke.curve_type != 'POLY':
                    skipped_not_poly += 1
                    continue
                if restrict_selected and not is_stroke_selected(stroke):
                    skipped_not_selected += 1
                    continue
                n = len(stroke.points)
                if n < 3:
                    skipped_too_short += 1
                    continue
                targets.append({
                    'index': si,
                    'points': extract_point_data(stroke),
                    'cyclic': bool(stroke.cyclic),
                })

            if not targets:
                self.report({'WARNING'}, "Aucun stroke a convertir.")
                return {'CANCELLED'}

            processed = 0
            total_before = 0
            total_after = 0
            processed_indices = []
            errors = []

            for tgt in targets:
                try:
                    new_points = build_catmull_points(
                        tgt['points'], tgt['cyclic'],
                        self.angle_threshold, self.cusp_angle,
                        self.curvature_step,
                    )
                    if not new_points or len(new_points) < 2:
                        continue
                    apply_points_to_stroke(drawing, tgt['index'], new_points)
                    total_before += len(tgt['points'])
                    total_after += len(new_points)
                    processed_indices.append(tgt['index'])
                    processed += 1
                except Exception as e:
                    errors.append(f"stroke #{tgt['index']}: {e}")

            if processed_indices:
                drawing.set_types(type='CATMULL_ROM', indices=processed_indices)

            if processed == 0:
                return {'CANCELLED'}

            try:
                drawing.tag_positions_changed()
            except Exception:
                pass
            obj.data.update_tag()
            context.view_layer.update()

            self.report({'INFO'}, f"{processed} stroke(s) converti(s).")
            return {'FINISHED'}

        except Exception as e:
            traceback.print_exc()
            self.report({'ERROR'}, f"Erreur pendant la conversion : {e}")
            return {'CANCELLED'}
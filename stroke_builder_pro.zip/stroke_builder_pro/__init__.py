bl_info = {
    "name": "Stroke Builder Pro",
    "author": "GP Tools",
    "version": (8, 0, 3),
    "blender": (5, 0, 1),
    "location": "View3D > N-Panel > GP Tools",
    "description": "Marqueurs, remplacement, copie, banque de frames, et simplification de tracés.",
    "category": "Grease Pencil",
}

import importlib
import bpy

from . import utils
from . import operators_replace
from . import operators_tools
from . import operators_reverse
from . import operators_bank
from . import operators_simplify
from . import ui

def _collect_classes():
    mods = (utils, operators_replace, operators_tools, operators_reverse, operators_bank, operators_simplify, ui)
    classes = []
    for m in mods:
        try:
            importlib.reload(m)
        except Exception:
            pass
        for name in dir(m):
            obj = getattr(m, name)
            if isinstance(obj, type) and issubclass(obj, (bpy.types.Operator, bpy.types.Panel, bpy.types.PropertyGroup, bpy.types.UIList)):
                if obj in (bpy.types.Operator, bpy.types.Panel, bpy.types.PropertyGroup, bpy.types.UIList):
                    continue
                if obj.__module__ != m.__name__:
                    continue
                if issubclass(obj, bpy.types.Panel) and obj.__name__ != "SO_PT_panel":
                    continue
                classes.append(obj)
    
    seen = set()
    out = []
    for c in classes:
        if c not in seen:
            out.append(c)
            seen.add(c)
    return out

classes = _collect_classes()

def register():
    for cls in classes:
        try:
            bpy.utils.register_class(cls)
        except Exception as e:
            print(f"[Stroke Organiser] Erreur enregistrement {cls}: {e}")

    try:
        if hasattr(utils, "StrokeOrganiserProps"):
            bpy.types.Scene.stroke_organiser_props = bpy.props.PointerProperty(type=utils.StrokeOrganiserProps)
    except Exception as e:
        print(f"[Stroke Organiser] Erreur proprietes: {e}")

    try:
        if hasattr(utils, "_overlay_on"):
            utils._overlay_on()
    except Exception:
        pass

def unregister():
    try:
        if hasattr(utils, "_stop_auto_layer_timer"):
            utils._stop_auto_layer_timer()
    except Exception:
        pass

    try:
        if hasattr(utils, "_overlay_off"):
            utils._overlay_off()
    except Exception:
        pass

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    try:
        if hasattr(bpy.types.Scene, "stroke_organiser_props"):
            del bpy.types.Scene.stroke_organiser_props
    except Exception:
        pass

if __name__ == "__main__":
    register()
import bpy
import blf
import gpu
import math
from mathutils import Vector
from gpu_extras.batch import batch_for_shader
import bpy_extras.view3d_utils as view3d_utils

# ═══════════════════════════════════════════════════════════════════════
# ÉTATS GLOBAUX PARTAGÉS
# ═══════════════════════════════════════════════════════════════════════

class _ReplaceState:
    active       = False
    obj          = None
    stroke_index = -1
    stroke_count = 0
    obj_name     = ""

_rs = _ReplaceState()

class _AssignState:
    active = False

_as = _AssignState()

class _StepperState:
    active        = False
    obj           = None
    frame_a       = None   
    frame_b       = None   
    frame_num_a   = 0
    frame_num_b   = 0
    t             = 0.5    
    temp_frame    = None   
    temp_frame_num = 0
    temp_frames   = []  

_ss = _StepperState()

_draw_handle = None

# ═══════════════════════════════════════════════════════════════════════
# ACCÈS API ET GEOMETRIE GLOBALISÉE (FIX MULTI-CALQUES)
# ═══════════════════════════════════════════════════════════════════════

def _gp_obj(context):
    obj = context.active_object or context.object
    return obj if (obj and obj.type == 'GREASEPENCIL') else None

def _get_drawing(obj):
    if not obj or obj.type != 'GREASEPENCIL': return None
    layer = obj.data.layers.active
    if not layer: return None
    frame = layer.current_frame()
    return frame.drawing if frame else None

def _get_strokes(obj):
    d = _get_drawing(obj)
    return d.strokes if d else None

def _find_selected_stroke_and_layer(obj):
    """Scanne tous les calques pour detecter quel stroke est selectionne"""
    if not obj or obj.type != 'GREASEPENCIL':
        return None, -1
    try:
        for layer in obj.data.layers:
            frame = layer.current_frame()
            if not frame: continue
            drawing = getattr(frame, 'drawing', None)
            if not drawing or not hasattr(drawing, 'strokes'): continue
            
            for si, stroke in enumerate(drawing.strokes):
                is_sel = False
                try:
                    if any(p.select for p in stroke.points): is_sel = True
                except:
                    if getattr(stroke, 'select', False): is_sel = True
                if is_sel:
                    return layer, si
    except:
        pass
    return None, -1

def _find_selected_stroke(obj):
    layer, si = _find_selected_stroke_and_layer(obj)
    return si

# ═══════════════════════════════════════════════════════════════════════
# TRACKING AUTOMATIQUE ET RÉACTIVITÉ ACCÉLÉRÉE (0.2s)
# ═══════════════════════════════════════════════════════════════════════

_auto_layer_timer = None

def _update_auto_layer_selection():
    try:
        ctx = bpy.context
        if not ctx or not ctx.scene: return 0.2
        props = getattr(ctx.scene, 'stroke_organiser_props', None)
        if not props: return 0.2
        
        if not props.auto_layer_toggle and not props.select_layer_toggle:
            return None
            
        obj = _gp_obj(ctx)
        if not obj: return 0.2
        
        if props.auto_layer_toggle:
            found_layer, si = _find_selected_stroke_and_layer(obj)
            if found_layer and obj.data.layers.active != found_layer:
                obj.data.layers.active = found_layer
                obj.data.update_tag()
                _redraw()
                
        if props.select_layer_toggle:
            layer = obj.data.layers.active
            if layer:
                frame = layer.current_frame()
                drawing = getattr(frame, 'drawing', None) if frame else None
                if drawing:
                    changed = False
                    for s in drawing.strokes:
                        if not s.select: s.select = True; changed = True
                        for p in s.points:
                            try:
                                if not p.select: p.select = True; changed = True
                            except: pass
                    if changed:
                        obj.data.update_tag()
        return 0.2
    except Exception:
        return 0.2

def _start_auto_layer_timer():
    global _auto_layer_timer
    if _auto_layer_timer is not None:
        try: bpy.app.timers.remove(_auto_layer_timer)
        except: pass
    _auto_layer_timer = bpy.app.timers.register(_update_auto_layer_selection)

def _stop_auto_layer_timer():
    global _auto_layer_timer
    if _auto_layer_timer is not None:
        try: bpy.app.timers.remove(_auto_layer_timer)
        except: pass
        _auto_layer_timer = None

def _auto_layer_update_callback(self, context):
    props = context.scene.stroke_organiser_props
    if props.auto_layer_toggle or props.select_layer_toggle:
        _start_auto_layer_timer()
    else:
        _stop_auto_layer_timer()

def _redraw_callback(self, context):
    _redraw()

def _stepper_update_callback(self, context):
    try:
        from . import operators_stepper
        if hasattr(operators_stepper, '_stepper_update_frame'):
            operators_stepper._stepper_update_frame(context)
    except Exception:
        pass

# ═══════════════════════════════════════════════════════════════════════
# PROPRIÉTÉS
# ═══════════════════════════════════════════════════════════════════════

class StrokeOrganiserBankItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Nom", default="Banque")
    frame_storage: bpy.props.IntProperty(name="Frame", default=1)
    is_empty: bpy.props.BoolProperty(default=False)

class StrokeOrganiserProps(bpy.types.PropertyGroup):
    show_numbers: bpy.props.BoolProperty(name="Numéros", default=True, update=_redraw_callback)
    show_current_marker: bpy.props.BoolProperty(name="Marqueur Actuel", default=True, update=_redraw_callback)
    show_prev_marker: bpy.props.BoolProperty(name="Marqueur Précédent", default=True, update=_redraw_callback)
    show_next_marker: bpy.props.BoolProperty(name="Marqueur Suivant", default=True, update=_redraw_callback)
    stepper_frame: bpy.props.IntProperty(name="Frame Target", default=1, min=0, update=_stepper_update_callback)
    banks: bpy.props.CollectionProperty(type=StrokeOrganiserBankItem)
    active_bank_idx: bpy.props.IntProperty(name="Index de Banque Actif", default=0)
    armature_target: bpy.props.PointerProperty(
        type=bpy.types.Object, name="Armature",
        poll=lambda self, obj: obj.type == 'ARMATURE'
    )
    auto_layer_toggle: bpy.props.BoolProperty(name="Auto Calque", default=False, update=_auto_layer_update_callback)
    select_layer_toggle: bpy.props.BoolProperty(name="Tous du Calque", default=False, update=_auto_layer_update_callback)
    
    # Propriétés de gestion de l'affichage repliable (True = Déplié par défaut)
    expand_markers: bpy.props.BoolProperty(name="Marqueurs", default=True)
    expand_reverse: bpy.props.BoolProperty(name="Inverser Stroke", default=True)
    expand_replace: bpy.props.BoolProperty(name="Remplacement", default=True)
    expand_stepper: bpy.props.BoolProperty(name="Interpolation Stepper", default=True)
    expand_quick: bpy.props.BoolProperty(name="Outils Rapides", default=True)
    expand_rigging: bpy.props.BoolProperty(name="Rigging", default=True)
    expand_bank: bpy.props.BoolProperty(name="Banque Manuelle", default=True)
    expand_simplify: bpy.props.BoolProperty(name="Smart Simplify", default=False)
    expand_corner: bpy.props.BoolProperty(name="Angle Catmull", default=True)

# ═══════════════════════════════════════════════════════════════════════
# CALCULS GÉOMÉTRIQUES STANDARD
# ═══════════════════════════════════════════════════════════════════════

def _drawing_of_frame(frame_obj):
    return getattr(frame_obj, 'drawing', None) if frame_obj else None

def _prev_frame(obj):
    if not obj or obj.type != 'GREASEPENCIL': return None
    layer = obj.data.layers.active
    if not layer or not layer.current_frame(): return None
    cur = layer.current_frame().frame_number
    best = None
    for fr in layer.frames:
        if fr.frame_number < cur:
            if best is None or fr.frame_number > best.frame_number: best = fr
    return best

def _next_frame(obj):
    if not obj or obj.type != 'GREASEPENCIL': return None
    layer = obj.data.layers.active
    if not layer or not layer.current_frame(): return None
    cur = layer.current_frame().frame_number
    best = None
    for fr in layer.frames:
        if fr.frame_number > cur:
            if best is None or fr.frame_number < best.frame_number: best = fr
    return best

def _get_pt_pos(p):
    return p.position if hasattr(p, 'position') else p.co

def _set_pt_pos(p, val):
    if hasattr(p, 'position'): p.position = val
    else: p.co = val

def _arc_lengths(stroke):
    pts = stroke.points
    n = len(pts)
    if n < 2: return [0.0] * n, 0.0
    cumul = [0.0]
    for i in range(1, n):
        seg = (Vector(_get_pt_pos(pts[i])) - Vector(_get_pt_pos(pts[i-1]))).length
        cumul.append(cumul[-1] + seg)
    total = cumul[-1]
    norm = [c / total for c in cumul] if total > 1e-9 else [i/(n-1) for i in range(n)]
    return norm, total

def _sample_stroke_at(stroke, t):
    arc, _ = _arc_lengths(stroke)
    pts = stroke.points
    n = len(pts)
    if n == 1: return Vector(_get_pt_pos(pts[0]))
    for i in range(n - 1):
        if arc[i] <= t <= arc[i+1]:
            span = arc[i+1] - arc[i]
            frac = (t - arc[i]) / span if span > 1e-9 else 0.0
            return Vector(_get_pt_pos(pts[i])) + (Vector(_get_pt_pos(pts[i+1])) - Vector(_get_pt_pos(pts[i]))) * frac
    return Vector(_get_pt_pos(pts[-1]))

def _sample_attr_at(stroke, attr, t):
    arc, _ = _arc_lengths(stroke)
    pts = stroke.points
    n = len(pts)
    if n == 1: return getattr(pts[0], attr, 0.0)
    for i in range(n - 1):
        if arc[i] <= t <= arc[i+1]:
            span = arc[i+1] - arc[i]
            frac = (t - arc[i]) / span if span > 1e-9 else 0.0
            return getattr(pts[i], attr, 0.0) + (getattr(pts[i+1], attr, 0.0) - getattr(pts[i], attr, 0.0)) * frac
    return getattr(pts[-1], attr, 0.0)

def _copy_geometry(src, dst):
    n_src = len(src.points)
    n_dst = len(dst.points)
    if n_src == 0 or n_dst == 0: return
    attrs = ('pressure', 'strength', 'uv_factor', 'uv_rotation')
    if n_src == n_dst:
        for i in range(n_dst):
            _set_pt_pos(dst.points[i], _get_pt_pos(src.points[i]))
            for a in attrs:
                if hasattr(src.points[i], a) and hasattr(dst.points[i], a):
                    setattr(dst.points[i], a, getattr(src.points[i], a))
    else:
        for i in range(n_dst):
            t = i / (n_dst - 1) if n_dst > 1 else 0.0
            _set_pt_pos(dst.points[i], _sample_stroke_at(src, t))
            for a in attrs:
                if hasattr(dst.points[i], a):
                    setattr(dst.points[i], a, _sample_attr_at(src, a, t))

def _proj(region, rv3d, obj, world_pos):
    return view3d_utils.location_3d_to_region_2d(region, rv3d, obj.matrix_world @ Vector(world_pos))

def _stroke_to_2d(region, rv3d, obj, stroke):
    res = []
    for p in stroke.points:
        c2 = _proj(region, rv3d, obj, _get_pt_pos(p))
        if not c2: return None
        res.append(c2)
    return res if len(res) >= 2 else None

def _centroid_2d(region, rv3d, obj, stroke):
    pts = stroke.points
    if not pts: return None
    c = Vector((0.0, 0.0, 0.0))
    for p in pts: c += Vector(_get_pt_pos(p))
    return _proj(region, rv3d, obj, c / len(pts))

# ═══════════════════════════════════════════════════════════════════════
# DESSIN VUE 3D (OVERLAY)
# ═══════════════════════════════════════════════════════════════════════

def _draw_stroke_marker(shader, region, rv3d, obj, stroke, stroke_idx, color_line, color_fill, label_prefix):
    co2d = _stroke_to_2d(region, rv3d, obj, stroke)
    if not co2d: return
    
    # 1. Dessin du tracé principal
    gpu.state.line_width_set(2.0)
    batch_l = batch_for_shader(shader, 'LINE_STRIP', {"pos": [(v.x, v.y) for v in co2d]})
    shader.bind(); shader.uniform_float("color", color_line); batch_l.draw(shader)
    
    # 2. Dessin des points géométriques
    gpu.state.point_size_set(6.0)
    batch_p = batch_for_shader(shader, 'POINTS', {"pos": [(v.x, v.y) for v in co2d]})
    shader.bind(); shader.uniform_float("color", color_fill); batch_p.draw(shader)
    
    p0 = co2d[0]
    
    # 3. Calcul et dessin de la flèche directionnelle
    if len(co2d) >= 2:
        p1 = co2d[1]
        dx = p1.x - p0.x
        dy = p1.y - p0.y
        
        idx = 2
        while dx*dx + dy*dy < 1e-4 and idx < len(co2d):
            p_next = co2d[idx]
            dx = p_next.x - p0.x
            dy = p_next.y - p0.y
            idx += 1
            
        dist = math.sqrt(dx*dx + dy*dy)
        if dist > 1e-4:
            ux = dx / dist
            uy = dy / dist
            
            arrow_len = 14.0
            arrow_angle = math.radians(30.0)
            
            base_angle = math.atan2(uy, ux)
            angle_left = base_angle + math.pi - arrow_angle
            angle_right = base_angle + math.pi + arrow_angle
            
            p_left = (
                p0.x + arrow_len * math.cos(angle_left),
                p0.y + arrow_len * math.sin(angle_left)
            )
            p_right = (
                p0.x + arrow_len * math.cos(angle_right),
                p0.y + arrow_len * math.sin(angle_right)
            )
            
            gpu.state.line_width_set(3.0)
            arrow_coords = [(p0.x, p0.y), p_left, (p0.x, p0.y), p_right]
            batch_arrow = batch_for_shader(shader, 'LINES', {"pos": arrow_coords})
            shader.bind(); shader.uniform_float("color", color_fill); batch_arrow.draw(shader)
    
    # 4. Dessin du texte
    fid = 0
    blf.color(fid, *color_fill); blf.position(fid, p0.x + 16, p0.y + 16, 0); blf.size(fid, 14)
    blf.draw(fid, f"{label_prefix} [{stroke_idx}]")

def _draw_callback():
    ctx = bpy.context
    if not ctx or not ctx.screen: return
    obj = _gp_obj(ctx)
    if not obj: return
    region = ctx.region; rv3d = ctx.region_data
    if not region or not rv3d: return
    strokes = _get_strokes(obj)
    if not strokes: return
    
    sel_idx = _find_selected_stroke(obj)
    props = ctx.scene.stroke_organiser_props
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')

    if props.show_numbers:
        fid = 0
        for i, s in enumerate(strokes):
            if not s.points: continue
            c_dot = _centroid_2d(region, rv3d, obj, s)
            c_num = _proj(region, rv3d, obj, _get_pt_pos(s.points[0]))
            if not c_dot or not c_num: continue
            
            is_sel = (i == sel_idx)
            col_pt = (1.0, 0.0, 0.0, 1.0) if is_sel else (0.9, 0.9, 0.9, 0.6)
            col_txt = (1.0, 0.0, 0.0, 1.0) if is_sel else (1.0, 1.0, 1.0, 0.8)
            gpu.state.point_size_set(8 if is_sel else 5)
            batch_dot = batch_for_shader(shader, 'POINTS', {"pos": [c_dot]})
            shader.bind(); shader.uniform_float("color", col_pt); batch_dot.draw(shader)
            
            blf.color(fid, *col_txt); blf.position(fid, c_num.x + 5, c_num.y + 5, 0); blf.size(fid, 15 if is_sel else 12)
            blf.draw(fid, str(i))

    if sel_idx >= 0 and props.show_current_marker:
        _draw_stroke_marker(shader, region, rv3d, obj, strokes[sel_idx], sel_idx, (1.0,0.0,0.0,0.9), (1.0,0.0,0.0,1.0), "Actuel")
    if props.show_prev_marker and sel_idx >= 0:
        pf = _prev_frame(obj)
        if pf:
            pd = _drawing_of_frame(pf)
            if pd and sel_idx < len(pd.strokes): _draw_stroke_marker(shader, region, rv3d, obj, pd.strokes[sel_idx], sel_idx, (0.0,0.85,0.2,0.85), (0.0,1.0,0.25,1.0), "Précédent")
    if props.show_next_marker and sel_idx >= 0:
        nf = _next_frame(obj)
        if nf:
            nd = _drawing_of_frame(nf)
            if nd and sel_idx < len(nd.strokes): _draw_stroke_marker(shader, region, rv3d, obj, nd.strokes[sel_idx], sel_idx, (0.1,0.5,1.0,0.85), (0.2,0.6,1.0,1.0), "Suivant")

    fid = 0
    if _rs.active:
        blf.size(fid, 13); blf.color(fid, 1.0, 0.85, 0.0, 1.0); blf.position(fid, 18, 44, 0); blf.draw(fid, "MODE REMPLACEMENT — Dessinez le nouveau tracé.")
        blf.color(fid, 0.8, 0.8, 0.8, 0.85); blf.position(fid, 18, 24, 0); blf.draw(fid, "Tab : valider  |  Échap : annuler")
    if _ss.active:
        blf.size(fid, 13); blf.color(fid, 0.4, 0.8, 1.0, 1.0); blf.position(fid, 18, 64, 0); blf.draw(fid, f"INTERPOLATION STEPPER  (frame active: {_ss.temp_frame_num} | t = {_ss.t:.2f})")
        blf.color(fid, 1.0, 1.0, 0.0, 1.0); blf.position(fid, 18, 44, 0); blf.draw(fid, "← / → : reculer/avancer d'une frame  |  Panneau N : Insérer / Annuler")

    gpu.state.point_size_set(1.0); gpu.state.line_width_set(1.0)

def _overlay_on():
    global _draw_handle
    if _draw_handle is None:
        _draw_handle = bpy.types.SpaceView3D.draw_handler_add(_draw_callback, (), 'WINDOW', 'POST_PIXEL')

def _overlay_off():
    global _draw_handle
    if _draw_handle is not None:
        try: bpy.types.SpaceView3D.draw_handler_remove(_draw_handle, 'WINDOW')
        except: pass
        _draw_handle = None

def _redraw():
    for w in bpy.context.window_manager.windows:
        for a in w.screen.areas:
            if a.type == 'VIEW_3D': a.tag_redraw()
import bpy
from .utils import _gp_obj, _rs, _ss

class SO_UL_bank_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        # Nom de la banque à gauche
        row.prop(item, "name", text="", emboss=False, icon='LIBRARY_DATA_DIRECT')
        # Valeur brute (frame) à droite sans le texte "Frame:"
        row.prop(item, "frame_storage", text="", emboss=True)

class SO_PT_panel(bpy.types.Panel):
    bl_label = "Stroke Organiser"
    bl_idname = "SO_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "GP Tools"

    @classmethod
    def poll(cls, context):
        return context.object is not None

    def draw(self, context):
        layout = self.layout
        props = context.scene.stroke_organiser_props
        obj = _gp_obj(context)
        
        in_edit = False
        if obj:
            in_edit = (obj.mode == 'EDIT') or (context.mode in {'EDIT_GREASE_PENCIL', 'EDIT', 'EDIT_GPENCIL'})
            
        from .utils import _next_frame
        nf = _next_frame(obj)

        # 1. MARQUEURS
        box = layout.box()
        head = box.row(align=True)
        arrow = 'TRIA_DOWN' if props.expand_markers else 'TRIA_RIGHT'
        head.prop(props, "expand_markers", text="", icon=arrow, emboss=False)
        head.prop(props, "expand_markers", text="Marqueurs", icon='HIDE_OFF', emboss=False)
        
        if props.expand_markers:
            col = box.column(align=True)
            col.enabled = obj is not None
            col.prop(props, "show_current_marker", toggle=True)
            col.prop(props, "show_prev_marker", toggle=True)
            col.prop(props, "show_next_marker", toggle=True)
            col.prop(props, "show_numbers", toggle=True)
        layout.separator()

        # 2. INVERSER STROKE
        box_reverse = layout.box()
        head_rev = box_reverse.row(align=True)
        arrow_rev = 'TRIA_DOWN' if props.expand_reverse else 'TRIA_RIGHT'
        head_rev.prop(props, "expand_reverse", text="", icon=arrow_rev, emboss=False)
        head_rev.prop(props, "expand_reverse", text="Inverser Stroke", icon='ARROW_LEFTRIGHT', emboss=False)
        
        if props.expand_reverse:
            col_reverse = box_reverse.column()
            col_reverse.scale_y = 1.3
            col_reverse.enabled = in_edit and not _ss.active and not _rs.active
            col_reverse.operator("stroke_organiser.reverse_stroke", text="Inverser", icon='ARROW_LEFTRIGHT')
        layout.separator()

        # 3. REMPLACEMENT
        box3 = layout.box()
        head3 = box3.row(align=True)
        arrow3 = 'TRIA_DOWN' if props.expand_replace else 'TRIA_RIGHT'
        head3.prop(props, "expand_replace", text="", icon=arrow3, emboss=False)
        head3.prop(props, "expand_replace", text="Remplacement", icon='FILE_REFRESH', emboss=False)
        
        if props.expand_replace:
            if not _rs.active:
                col3 = box3.column()
                col3.scale_y = 1.3
                col3.enabled = in_edit and not _ss.active
                col3.operator("stroke_organiser.replace", text="Replace Stroke (Shift+E)")
            else:
                inner3 = box3.box()
                inner3.label(text="Remplacement actif...")
                box3.operator("stroke_organiser.cancel_replace", text="Annuler (Échap)", icon='X')
        layout.separator()

        # 4. STEPPER
        box4 = layout.box()
        head4 = box4.row(align=True)
        arrow4 = 'TRIA_DOWN' if props.expand_stepper else 'TRIA_RIGHT'
        head4.prop(props, "expand_stepper", text="", icon=arrow4, emboss=False)
        head4.prop(props, "expand_stepper", text="Interpolation Stepper", icon='IPO_BEZIER', emboss=False)
        
        if props.expand_stepper:
            if not _ss.active:
                col4 = box4.column()
                col4.scale_y = 1.3
                col4.enabled = not _rs.active and nf is not None
                col4.operator("stroke_organiser.stepper_start", text="Démarrer Stepper", icon='IPO_BEZIER')
            else:
                inner4 = box4.box()
                inner4.label(text=f"Intervalle : {_ss.frame_num_a} → {_ss.frame_num_b}")
                inner4.label(text=f"Ratio t interpolé : {_ss.t:.2f}", icon='FCURVE')
                inner4.prop(props, "stepper_frame", text="Frame Target")
                inner4.label(text="Flèches ← / → pour naviguer", icon='INFO')
                row4 = box4.row(align=True)
                row4.operator("stroke_organiser.stepper_insert", text="Fixer l'in-between", icon='CHECKMARK')
                row4.operator("stroke_organiser.stepper_cancel", text="Annuler", icon='X')
        layout.separator()

        # 5. OUTILS RAPIDES
        box5 = layout.box()
        head5 = box5.row(align=True)
        arrow5 = 'TRIA_DOWN' if props.expand_quick else 'TRIA_RIGHT'
        head5.prop(props, "expand_quick", text="", icon=arrow5, emboss=False)
        head5.prop(props, "expand_quick", text="Outils Rapides", icon='TOOL_SETTINGS', emboss=False)
        
        if props.expand_quick:
            col_toggles = box5.column(align=True)
            col_toggles.enabled = True 
            
            row_toggles = col_toggles.row(align=True)
            row_toggles.scale_y = 1.3
            row_toggles.prop(props, "auto_layer_toggle", toggle=True, text="Auto Calque", icon='RESTRICT_SELECT_OFF')
            
            row_select = col_toggles.row(align=True)
            row_select.scale_y = 1.3
            row_select.enabled = props.auto_layer_toggle
            row_select.prop(props, "select_layer_toggle", toggle=True, text="Tous du Calque", icon='GP_SELECT_STROKES')
            
            box5.separator()

            col_copy = box5.column(align=True)
            col_copy.enabled = in_edit and not _ss.active and not _rs.active
            op_prev = col_copy.operator("stroke_organiser.copy_from_neighbor", text="Copier de la précédente")
            op_prev.direction = 'PREV'
            op_next = col_copy.operator("stroke_organiser.copy_from_neighbor", text="Copier de la suivante")
            op_next.direction = 'NEXT'
        layout.separator()

        # 6. RIGGING
        box6 = layout.box()
        head6 = box6.row(align=True)
        arrow6 = 'TRIA_DOWN' if props.expand_rigging else 'TRIA_RIGHT'
        head6.prop(props, "expand_rigging", text="", icon=arrow6, emboss=False)
        head6.prop(props, "expand_rigging", text="Génération de Vertex Groups", icon='GROUP_VERTEX', emboss=False)
        
        if props.expand_rigging:
            box6.prop(props, "armature_target", text="Cible")
            col_btn = box6.column()
            col_btn.scale_y = 1.3
            col_btn.enabled = props.armature_target is not None
            col_btn.operator("stroke_organiser.create_vertex_groups", text="Valider la génération", icon='ARMATURE_DATA')
        layout.separator()

        # 7. BANQUE MANUELLE
        box_bank = layout.box()
        head_bank = box_bank.row(align=True)
        arrow_bank = 'TRIA_DOWN' if props.expand_bank else 'TRIA_RIGHT'
        head_bank.prop(props, "expand_bank", text="", icon=arrow_bank, emboss=False)
        head_bank.prop(props, "expand_bank", text="Banque Manuelle", icon='LIBRARY_DATA_DIRECT', emboss=False)
        
        if props.expand_bank:
            row_bank = box_bank.row()
            row_bank.template_list("SO_UL_bank_list", "", props, "banks", props, "active_bank_idx", rows=4)
            
            col_list_btns = row_bank.column(align=True)
            col_list_btns.operator("stroke_organiser.bank_add", icon='ADD', text="")
            col_list_btns.operator("stroke_organiser.bank_remove", icon='REMOVE', text="")
            
            if len(props.banks) > 0:
                box_bank.separator()
                col_action = box_bank.column(align=True)
                col_action.scale_y = 1.2
                col_action.operator("stroke_organiser.bank_assign", text="Sauvegarder Frame vers Banque", icon='IMPORT')
                
                col_paste = box_bank.column(align=True)
                col_paste.scale_y = 1.2
                col_paste.operator("stroke_organiser.bank_paste", text="Coller Banque sur Frame", icon='EXPORT')
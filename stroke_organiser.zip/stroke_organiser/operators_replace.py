import bpy
from .utils import _gp_obj, _get_drawing, _get_strokes, _copy_geometry, _find_selected_stroke, _redraw, _rs

def _execute_commit(obj):
    if not obj:
        _rs.active = False
        return False
        
    old_mode = obj.mode
    
    try:
        if old_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
            
        drawing = _get_drawing(obj)
        strokes = drawing.strokes if drawing else None
        if not strokes or len(strokes) <= _rs.stroke_count:
            _rs.active = False
            if old_mode != 'OBJECT': 
                bpy.ops.object.mode_set(mode=old_mode)
            return False
            
        target = strokes[_rs.stroke_index]
        new_stroke = strokes[len(strokes) - 1]
        
        if len(new_stroke.points) == 0:
            _rs.active = False
            if old_mode != 'OBJECT': 
                bpy.ops.object.mode_set(mode=old_mode)
            return False
            
        is_bezier = hasattr(target, 'type') and target.type == 'BEZIER'
        
        if is_bezier:
            bpy.ops.object.mode_set(mode='EDIT')
            
            for s in strokes:
                s.select = False
                if hasattr(s, 'points'):
                    for p in s.points: 
                        try: p.select = False
                        except: pass
            
            new_stroke.select = True
            for p in new_stroke.points: 
                try: p.select = True
                except: pass
                
            target_pts = len(target.points)
            new_pts = len(new_stroke.points)
            calc_threshold = 0.02
            if target_pts > 0 and new_pts > 0:
                ratio = new_pts / target_pts
                calc_threshold = max(0.005, min(0.1, 0.01 * (ratio / 2.0)))
            
            try:
                bpy.ops.grease_pencil.convert_curve_type(type='BEZIER', threshold=calc_threshold)
            except Exception as e:
                print(f"[Stroke Organiser] Erreur conversion Bézier : {e}")
                
            bpy.ops.object.mode_set(mode='OBJECT')
            
            n_new = len(new_stroke.points)
            
            try: drawing.set_types(type='BEZIER', indices=[_rs.stroke_index])
            except: 
                try: target.type = 'BEZIER'
                except: pass
                
            try: drawing.resize_strokes([n_new], indices=[_rs.stroke_index])
            except: pass
            
            _copy_geometry(new_stroke, target)
        else:
            _copy_geometry(new_stroke, target)
            
        if drawing and len(strokes) > _rs.stroke_count:
            indices_to_remove = list(range(_rs.stroke_count, len(strokes)))
            try:
                drawing.remove_strokes(indices=indices_to_remove)
            except Exception as e:
                print(f"Replace removal error: {e}")
                
        obj.data.update_tag()
        
    except Exception as e:
        print(f"Replace commit error: {e}")
    finally:
        try:
            if bpy.context.object.mode != old_mode:
                bpy.ops.object.mode_set(mode=old_mode)
        except: pass
        
        try:
            strokes = _get_strokes(obj)
            if strokes and 0 <= _rs.stroke_index < len(strokes):
                for s in strokes: s.select = False
                t = strokes[_rs.stroke_index]
                t.select = True
                for p in t.points: 
                    try: p.select = True
                    except: pass
        except: pass
        
        _rs.active = False
        
    return True

class SO_OT_replace(bpy.types.Operator):
    bl_idname = "stroke_organiser.replace"
    bl_label = "Replace Stroke"
    bl_description = "Mémorise le stroke → Draw Mode. Dessinez, Tab pour valider."
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        from .utils import _as, _ss
        obj = _gp_obj(context)
        if not obj:
            return False
        # Poll ultra-sécurisé via obj.mode
        in_edit = (obj.mode == 'EDIT') or (context.mode in {'EDIT_GREASE_PENCIL', 'EDIT', 'EDIT_GPENCIL'})
        return (in_edit and not _rs.active and not _as.active and not _ss.active)

    def execute(self, context):
        obj = _gp_obj(context)
        si = _find_selected_stroke(obj)
        if si == -1:
            self.report({'WARNING'}, "Sélectionnez au moins un point du stroke cible.")
            return {'CANCELLED'}
        strokes = _get_strokes(obj)
        
        _rs.active = True
        _rs.obj_name = obj.name
        _rs.stroke_index = si
        _rs.stroke_count = len(strokes) if strokes else 0
        _redraw()
        
        try: 
            bpy.ops.object.mode_set(mode='PAINT_GREASE_PENCIL')
        except:
            _rs.active = False
            return {'CANCELLED'}
            
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not getattr(_rs, 'active', False): 
            return {'FINISHED'}
            
        obj_name = getattr(_rs, 'obj_name', "")
        obj = bpy.data.objects.get(obj_name) if obj_name else None
        
        if not obj:
            _rs.active = False
            _redraw()
            self.report({'WARNING'}, "Objet cible perdu ou indisponible. Mode remplacement réinitialisé.")
            return {'FINISHED'}

        if event.type == 'ESC' and event.value == 'PRESS':
            bpy.ops.stroke_organiser.cancel_replace('EXEC_DEFAULT')
            return {'FINISHED'}
            
        if context.mode not in {'PAINT_GREASE_PENCIL'}:
            ok = _execute_commit(obj)
            _redraw()
            if ok: 
                self.report({'INFO'}, f"Stroke [{_rs.stroke_index}] remplacé.")
            return {'FINISHED'}
            
        if event.type == 'MOUSEMOVE': 
            _redraw()
            
        return {'PASS_THROUGH'}

class SO_OT_cancel(bpy.types.Operator):
    bl_idname = "stroke_organiser.cancel_replace"
    bl_label = "Annuler Replace"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj_name = getattr(_rs, 'obj_name', "")
        obj = bpy.data.objects.get(obj_name) if obj_name else None
        
        old_mode = obj.mode if obj else 'EDIT'
        try:
            if obj and obj.mode == 'PAINT_GREASE_PENCIL': 
                bpy.ops.object.mode_set(mode='OBJECT')
        except: pass
        
        if obj:
            try:
                drawing = _get_drawing(obj)
                if drawing:
                    strokes = drawing.strokes
                    if len(strokes) > _rs.stroke_count:
                        indices_to_remove = list(range(_rs.stroke_count, len(strokes)))
                        drawing.remove_strokes(indices=indices_to_remove)
                obj.data.update_tag()
            except: pass
            
            try:
                if old_mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode=old_mode)
                strokes = _get_strokes(obj)
                if strokes and 0 <= _rs.stroke_index < len(strokes):
                    t = strokes[_rs.stroke_index]
                    t.select = True
                    for p in t.points: 
                        try: p.select = True
                        except: pass
            except: pass
            
        _rs.active = False
        _rs.obj_name = ""
        _redraw()
        self.report({'INFO'}, "Remplacement annulé.")
        return {'FINISHED'}

class SO_OT_reset_states(bpy.types.Operator):
    bl_idname = "stroke_organiser.reset_states"
    bl_label = "Réinitialiser États"
    bl_description = "Force la libération des variables de l'add-on si un bouton reste bloqué ou grisé"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        from .utils import _as, _ss, _rs, _redraw
        _rs.active = False
        _ss.active = False
        _as.active = False
        _redraw()
        self.report({'INFO'}, "États de l'add-on réinitialisés avec succès.")
        return {'FINISHED'}
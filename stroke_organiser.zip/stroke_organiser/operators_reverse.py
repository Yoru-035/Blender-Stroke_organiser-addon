"""
Stroke Reverse Operator
Inverse le point de départ et d'arrivée d'un stroke sélectionné
"""

import bpy
from bpy.types import Operator


class STROKE_ORGANISER_OT_reverse_stroke(Operator):
    """Inverse le point de départ et d'arrivée d'un stroke"""
    bl_idname = "stroke_organiser.reverse_stroke"
    bl_label = "Inverser le stroke"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        """Vérifie qu'on est en edit mode Grease Pencil / Annotation"""
        obj = context.object
        if obj is None:
            return False
        if obj.type != 'GREASEPENCIL':
            return False
        if context.mode != 'EDIT_GREASE_PENCIL':
            return False
        # Vérification supplémentaire : couche et frame actifs
        if not getattr(obj.data.layers, "active", None):
            return False
        if not getattr(obj.data.layers.active, "active_frame", None):
            return False
        return True

    def execute(self, context):
        """Exécute l'inversion du/des stroke(s) sélectionné(s)"""
        gp = context.object.data
        layer = gp.layers.active
        frame = layer.active_frame
        reversed_count = 0

        # Récupérer la collection de strokes de façon compatible
        strokes_collection = None
        if hasattr(frame, "strokes"):
            strokes_collection = frame.strokes
        elif hasattr(frame, "drawing") and hasattr(frame.drawing, "strokes"):
            strokes_collection = frame.drawing.strokes
        else:
            self.report({'ERROR'}, "Impossible d'accéder aux strokes pour cette version de Blender")
            return {'CANCELLED'}

        # Helpers pour lire/écrire la position d'un point de façon compatible
        def get_point_pos(point):
            if hasattr(point, "location"):
                return point.location.copy()
            if hasattr(point, "co"):
                return point.co.copy()
            # fallback: try vector-like attributes
            for attr in ("position", "pos"):
                if hasattr(point, attr):
                    return getattr(point, attr).copy()
            return None

        def set_point_pos(point, vec):
            # Écrire dans la propriété disponible
            if hasattr(point, "location"):
                point.location = vec
            if hasattr(point, "co"):
                point.co = vec
            for attr in ("position", "pos"):
                if hasattr(point, attr):
                    setattr(point, attr, vec)

        # Parcourir les strokes
        for stroke in strokes_collection:
            # compatibilité pour la sélection
            if not getattr(stroke, "select", False) and not getattr(stroke, "select_start", False):
                # certains builds utilisent select_start/select_end ; on vérifie au moins select
                continue

            try:
                points = getattr(stroke, "points", None)
                if points is None:
                    # certains types utilisent "points" ou "points" est absent
                    continue

                if len(points) > 1:
                    # Sauvegarder les données des points
                    points_data = []
                    for point in points:
                        pos = get_point_pos(point)
                        if pos is None:
                            raise RuntimeError("Impossible de lire la position d'un point (attribut manquant)")
                        points_data.append({
                            'pos': pos,
                            'pressure': getattr(point, 'pressure', 1.0),
                            'strength': getattr(point, 'strength', getattr(point, 'vertex_strength', 1.0)),
                            'vertex_color': getattr(point, 'vertex_color', None)[:] if getattr(point, 'vertex_color', None) is not None else None,
                            'uv_factor': getattr(point, 'uv_factor', None),
                            'uv_rotation': getattr(point, 'uv_rotation', None),
                            'uv_scale': getattr(point, 'uv_scale', None),
                        })

                    # Inverser l'ordre des données
                    points_data.reverse()

                    # Réassigner les données aux points dans l'ordre inverse
                    for i, point in enumerate(points):
                        data = points_data[i]
                        set_point_pos(point, data['pos'])
                        if hasattr(point, 'pressure') and data['pressure'] is not None:
                            point.pressure = data['pressure']
                        if hasattr(point, 'strength') and data['strength'] is not None:
                            point.strength = data['strength']
                        if getattr(point, 'vertex_color', None) is not None and data['vertex_color'] is not None:
                            try:
                                point.vertex_color[:] = data['vertex_color']
                            except Exception:
                                # certains types peuvent ne pas accepter l'affectation slice
                                point.vertex_color = data['vertex_color']
                        if data['uv_factor'] is not None and hasattr(point, 'uv_factor'):
                            point.uv_factor = data['uv_factor']
                        if data['uv_rotation'] is not None and hasattr(point, 'uv_rotation'):
                            point.uv_rotation = data['uv_rotation']
                        if data['uv_scale'] is not None and hasattr(point, 'uv_scale'):
                            point.uv_scale = data['uv_scale']

                    reversed_count += 1

            except Exception as e:
                self.report({'ERROR'}, f"Erreur lors de l'inversion: {str(e)}")
                return {'FINISHED'}

        # Message de succès
        if reversed_count > 0:
            if reversed_count == 1:
                self.report({'INFO'}, "Stroke inversé avec succès")
            else:
                self.report({'INFO'}, f"{reversed_count} strokes inversés avec succès")
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Aucun stroke à inverser")
            return {'FINISHED'}


# Enregistrement simple de l'addon
classes = (STROKE_ORGANISER_OT_reverse_stroke,)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()

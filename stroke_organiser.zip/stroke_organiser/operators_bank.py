import bpy

def _find_target_obj(context):
    """Cherche l'objet actif ou selectionne (GP, Mesh, Armature...)"""
    if context.active_object:
        return context.active_object
    if context.selected_objects:
        return context.selected_objects[0]
    return None

def _get_all_fcurves(action):
    """Récupère toutes les fcurves d'une action, compatible Blender 5.0 (Slotted Actions) et < 5.0"""
    fcurves = []
    # Système legacy (< Blender 4.4 ou action non-slotted)
    if hasattr(action, "fcurves"):
        try:
            fcurves.extend(action.fcurves)
            return fcurves
        except AttributeError:
            pass
            
    # Nouveau système Blender 4.4 / 5.0+ (Layered & Slotted Actions)
    if hasattr(action, "layers"):
        for layer in action.layers:
            if hasattr(layer, "strips"):
                for strip in layer.strips:
                    if hasattr(strip, "channelbags"):
                        for cb in strip.channelbags:
                            if hasattr(cb, "fcurves"):
                                fcurves.extend(cb.fcurves)
    return fcurves

class SO_OT_bank_add(bpy.types.Operator):
    bl_idname = "stroke_organiser.bank_add"
    bl_label = "Ajouter une Banque"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        props = context.scene.stroke_organiser_props
        new_item = props.banks.add()
        new_item.frame_storage = context.scene.frame_current
        new_item.name = f"Banque {len(props.banks)}"
        new_item.is_empty = False
        props.active_bank_idx = len(props.banks) - 1
        return {'FINISHED'}

class SO_OT_bank_remove(bpy.types.Operator):
    bl_idname = "stroke_organiser.bank_remove"
    bl_label = "Supprimer"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context):
        props = getattr(context.scene, 'stroke_organiser_props', None)
        return props and len(props.banks) > 0

    def execute(self, context):
        props = context.scene.stroke_organiser_props
        idx = props.active_bank_idx
        props.banks.remove(idx)
        if props.active_bank_idx > 0:
            props.active_bank_idx -= 1
        return {'FINISHED'}

class SO_OT_bank_assign(bpy.types.Operator):
    bl_idname = "stroke_organiser.bank_assign"
    bl_label = "Sauvegarder vers banque"
    bl_description = "Enregistre la frame courante comme index de reference pour cette banque"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        props = getattr(context.scene, 'stroke_organiser_props', None)
        return props and len(props.banks) > 0

    def execute(self, context):
        props = context.scene.stroke_organiser_props
        bank = props.banks[props.active_bank_idx]
        bank.frame_storage = context.scene.frame_current
        bank.is_empty = False
        self.report({'INFO'}, f"Frame {bank.frame_storage} assignee a '{bank.name}'.")
        return {'FINISHED'}

class SO_OT_bank_paste(bpy.types.Operator):
    bl_idname = "stroke_organiser.bank_paste"
    bl_label = "Coller depuis la banque"
    bl_description = "Copie les données de la frame reference vers la frame actuelle (GPencil, Objets, Armatures)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        props = getattr(context.scene, 'stroke_organiser_props', None)
        return props and len(props.banks) > 0 and _find_target_obj(context) is not None

    def execute(self, context):
        props = context.scene.stroke_organiser_props
        if props.active_bank_idx >= len(props.banks):
            return {'CANCELLED'}
            
        bank = props.banks[props.active_bank_idx]
        obj = _find_target_obj(context)
        
        if not obj:
            self.report({'ERROR'}, "Aucun objet selectionne ou actif trouve.")
            return {'CANCELLED'}
            
        current_frame = context.scene.frame_current
        target_frame = bank.frame_storage
        
        if current_frame == target_frame:
            self.report({'WARNING'}, "Vous etes deja sur la frame cible.")
            return {'CANCELLED'}

        # -------------------------------------------------------------
        # BRANCH 1 : GREASE PENCIL (Copie géométrique)
        # -------------------------------------------------------------
        if obj.type == 'GREASEPENCIL':
            orig_active = context.view_layer.objects.active
            orig_mode = orig_active.mode if orig_active else 'OBJECT'
            orig_selected = list(context.selected_objects)
            
            if orig_active and orig_mode != 'OBJECT':
                try: bpy.ops.object.mode_set(mode='OBJECT')
                except Exception: pass
            
            for o in context.view_layer.objects:
                try: o.select_set(False)
                except: pass
                
            obj.select_set(True)
            context.view_layer.objects.active = obj
            
            is_v3 = bpy.app.version >= (4, 3, 0)
            gp_edit_mode = 'EDIT' if is_v3 else 'EDIT_GREASE_PENCIL'
            
            old_handlers_pre = list(bpy.app.handlers.frame_change_pre)
            old_handlers_post = list(bpy.app.handlers.frame_change_post)
            bpy.app.handlers.frame_change_pre.clear()
            bpy.app.handlers.frame_change_post.clear()
            
            try:
                context.scene.frame_current = target_frame
                context.view_layer.update()
                
                bpy.ops.object.mode_set(mode=gp_edit_mode)
                if is_v3:
                    bpy.ops.grease_pencil.select_all(action='SELECT')
                    bpy.ops.grease_pencil.copy()
                else:
                    bpy.ops.gpencil.select_all(action='SELECT')
                    bpy.ops.gpencil.copy()
                    
                bpy.ops.object.mode_set(mode='OBJECT')
                context.scene.frame_current = current_frame
                context.view_layer.update()
                
                bpy.ops.object.mode_set(mode=gp_edit_mode)
                try:
                    if is_v3:
                        bpy.ops.grease_pencil.select_all(action='SELECT')
                        bpy.ops.grease_pencil.delete(type='POINTS')
                    else:
                        bpy.ops.gpencil.select_all(action='SELECT')
                        bpy.ops.gpencil.delete(type='POINTS')
                except: pass
                    
                if is_v3:
                    bpy.ops.grease_pencil.paste()
                else:
                    bpy.ops.gpencil.paste()
                    
                bpy.ops.object.mode_set(mode='OBJECT')
                self.report({'INFO'}, f"Banque GP appliquée sur la frame {current_frame}.")
                
            except Exception as e:
                self.report({'ERROR'}, f"Erreur de transfert GP : {str(e)}")
                return {'CANCELLED'}
                
            finally:
                bpy.app.handlers.frame_change_pre.extend(old_handlers_pre)
                bpy.app.handlers.frame_change_post.extend(old_handlers_post)
                
                for o in context.view_layer.objects:
                    try: o.select_set(False)
                    except: pass
                for o in orig_selected:
                    try: o.select_set(True)
                    except: pass
                if orig_active:
                    try:
                        context.view_layer.objects.active = orig_active
                        if orig_mode != 'OBJECT':
                            bpy.ops.object.mode_set(mode=orig_mode)
                    except Exception: pass

        # -------------------------------------------------------------
        # BRANCH 2 : AUTRES OBJETS / ARMATURES (Copie Keyframes/F-Curves)
        # -------------------------------------------------------------
        else:
            try:
                copied_curves = 0
                
                # 1. Copie des F-Curves de l'objet (Transforms, Pose Bones, Custom Props...)
                if obj.animation_data and obj.animation_data.action:
                    fcurves = _get_all_fcurves(obj.animation_data.action)
                    for fc in fcurves:
                        val = fc.evaluate(target_frame)
                        fc.keyframe_points.insert(current_frame, val)
                        fc.update()
                        copied_curves += 1
                
                # 2. Copie des F-Curves des Data de l'objet (Shape Keys, Camera Fov...)
                if obj.data and getattr(obj.data, 'animation_data', None) and obj.data.animation_data.action:
                    fcurves_data = _get_all_fcurves(obj.data.animation_data.action)
                    for fc in fcurves_data:
                        val = fc.evaluate(target_frame)
                        fc.keyframe_points.insert(current_frame, val)
                        fc.update()
                        copied_curves += 1
                
                context.view_layer.update()
                
                if copied_curves > 0:
                    self.report({'INFO'}, f"Animation ({copied_curves} courbes) appliquée sur la frame {current_frame}.")
                else:
                    self.report({'WARNING'}, f"L'objet ne possede pas d'animation a dupliquer.")
                    
            except Exception as e:
                self.report({'ERROR'}, f"Erreur de copie d'animation : {str(e)}")
                return {'CANCELLED'}

        return {'FINISHED'}
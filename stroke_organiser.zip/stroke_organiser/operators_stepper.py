import bpy
from mathutils import Vector
from .utils import _gp_obj, _next_frame, _prev_frame, _drawing_of_frame, _copy_geometry, _sample_stroke_at, _sample_attr_at, _set_pt_pos, _get_pt_pos, _redraw, _ss

def _create_stroke_snapshot(stroke, drawing, stroke_idx=None):
    """Create a complete snapshot of a stroke with all attributes including point properties."""
    snapshot = {
        'positions': [Vector(_get_pt_pos(p)) for p in stroke.points],
        'material_index': getattr(stroke, 'material_index', 0),
        'point_properties': [],  # weight, pressure, strength, radius, opacity, vertex_color
        'curve_attrs': {},
        'point_attrs': {}
    }
    
    # If stroke_idx not provided, find it
    if stroke_idx is None:
        try:
            stroke_idx = int(stroke._index)
        except:
            for i, s in enumerate(drawing.strokes):
                if s is stroke:
                    stroke_idx = i
                    break
    
    # Extract point properties (GPv2 & GPv3 compatibility)
    for p in stroke.points:
        props = {
            'weight': getattr(p, 'weight', 1.0),
            'pressure': getattr(p, 'pressure', 1.0),
            'strength': getattr(p, 'strength', 1.0),
            'radius': getattr(p, 'radius', 0.01),   # GPv3 Thickness
            'opacity': getattr(p, 'opacity', 1.0),  # GPv3 Opacity
            'vertex_color': None
        }
        
        # Try to get vertex_color if it exists
        try:
            if hasattr(p, 'vertex_color'):
                color = getattr(p, 'vertex_color')
                if color is not None:
                    # Store as list for easier interpolation
                    props['vertex_color'] = list(color) if hasattr(color, '__iter__') else [color, color, color, color]
        except:
            pass
        
        snapshot['point_properties'].append(props)
    
    # Extract drawing attributes
    pt_offset = 0
    n_pts = len(stroke.points)
    
    # Calculate point offset for this stroke
    pt_offset = sum(len(drawing.strokes[i].points) for i in range(stroke_idx))
    
    for attr in drawing.attributes:
        p_name = 'vector' if attr.data_type in {'FLOAT_VECTOR', 'FLOAT2'} else ('color' if attr.data_type in {'FLOAT_COLOR', 'BYTE_COLOR'} else 'value')
        
        if attr.domain == 'CURVE':
            try:
                val = getattr(attr.data[stroke_idx], p_name)
                snapshot['curve_attrs'][attr.name] = val.copy() if hasattr(val, "copy") else (list(val) if hasattr(val, "__iter__") else val)
            except:
                pass
        elif attr.domain == 'POINT':
            vals = []
            for j in range(n_pts):
                try:
                    val = getattr(attr.data[pt_offset + j], p_name)
                    vals.append(val.copy() if hasattr(val, "copy") else (list(val) if hasattr(val, "__iter__") else val))
                except:
                    vals.append(None)
            snapshot['point_attrs'][attr.name] = vals
    
    return snapshot

def _interp_stroke_from_snapshots(snap_a, snap_b, dst, t, attr_info):
    """Interpolate stroke from saved snapshots including point properties."""
    n_dst = len(dst.points)
    if n_dst == 0: 
        return
    
    pos_a = snap_a['positions']
    pos_b = snap_b['positions']
    props_a = snap_a.get('point_properties', [])
    props_b = snap_b.get('point_properties', [])
    
    len_a = len(pos_a)
    len_b = len(pos_b)
    
    if len_a == 0 or len_b == 0:
        return
    
    for i in range(n_dst):
        dp = dst.points[i]
        norm = i / (n_dst - 1) if n_dst > 1 else 0.0
        
        # Sample position from both strokes independently
        if len_a > 1:
            idx_a_1 = int(norm * (len_a - 1))
            idx_a_2 = min(idx_a_1 + 1, len_a - 1)
            local_t_a = norm * (len_a - 1) - idx_a_1
            p_a_interp = pos_a[idx_a_1] + (pos_a[idx_a_2] - pos_a[idx_a_1]) * local_t_a
        else:
            p_a_interp = pos_a[0]
        
        if len_b > 1:
            idx_b_1 = int(norm * (len_b - 1))
            idx_b_2 = min(idx_b_1 + 1, len_b - 1)
            local_t_b = norm * (len_b - 1) - idx_b_1
            p_b_interp = pos_b[idx_b_1] + (pos_b[idx_b_2] - pos_b[idx_b_1]) * local_t_b
        else:
            p_b_interp = pos_b[0]
        
        # Final position interpolation between frame A and frame B
        final_pos = p_a_interp + (p_b_interp - p_a_interp) * t
        _set_pt_pos(dp, final_pos)
        
        # Interpolate point properties
        if i < len(props_a) and i < len(props_b):
            prop_a = props_a[i]
            prop_b = props_b[i]
            
            # Interpolate weight (GPv2)
            try:
                w_a = prop_a.get('weight', 1.0)
                w_b = prop_b.get('weight', 1.0)
                setattr(dp, 'weight', w_a * (1 - t) + w_b * t)
            except: pass
            
            # Interpolate pressure (GPv2)
            try:
                pr_a = prop_a.get('pressure', 1.0)
                pr_b = prop_b.get('pressure', 1.0)
                setattr(dp, 'pressure', pr_a * (1 - t) + pr_b * t)
            except: pass
            
            # Interpolate radius (GPv3 Thickness)
            try:
                rad_a = prop_a.get('radius', 0.01)
                rad_b = prop_b.get('radius', 0.01)
                setattr(dp, 'radius', rad_a * (1 - t) + rad_b * t)
            except: pass
            
            # Interpolate strength (GPv2)
            try:
                s_a = prop_a.get('strength', 1.0)
                s_b = prop_b.get('strength', 1.0)
                setattr(dp, 'strength', s_a * (1 - t) + s_b * t)
            except: pass
            
            # Interpolate opacity (GPv3 Opacity)
            try:
                op_a = prop_a.get('opacity', 1.0)
                op_b = prop_b.get('opacity', 1.0)
                setattr(dp, 'opacity', op_a * (1 - t) + op_b * t)
            except: pass
            
            # Interpolate vertex_color
            try:
                vc_a = prop_a.get('vertex_color')
                vc_b = prop_b.get('vertex_color')
                if vc_a is not None and vc_b is not None:
                    color = [vc_a[j] * (1 - t) + vc_b[j] * t for j in range(len(vc_a))]
                    setattr(dp, 'vertex_color', color)
            except: pass

def _apply_point_attrs_to_stroke(dst, snap_a, snap_b, t, attr_info, drawing, stroke_idx, pt_offset):
    """Apply interpolated point attributes to destination stroke."""
    n_dst = len(dst.points)
    if n_dst == 0:
        return
    
    # Ensure point_properties exist (backward compatibility)
    if 'point_properties' not in snap_a: snap_a['point_properties'] = []
    if 'point_properties' not in snap_b: snap_b['point_properties'] = []
    
    for attr_name, info in attr_info.items():
        if info['domain'] == 'POINT':
            attr = drawing.attributes.get(attr_name)
            if not attr:
                continue
            
            vals_a = snap_a['point_attrs'].get(attr_name, [])
            vals_b = snap_b['point_attrs'].get(attr_name, [])
            
            if not vals_a or not vals_b:
                continue
            
            p_name = info['p_name']
            len_a = len(vals_a)
            len_b = len(vals_b)
            
            if len_a == 0 or len_b == 0:
                continue
            
            for i in range(n_dst):
                norm = i / (n_dst - 1) if n_dst > 1 else 0.0
                
                # Sample from source attributes independently
                if len_a > 1:
                    idx_a_1 = int(norm * (len_a - 1))
                    idx_a_2 = min(idx_a_1 + 1, len_a - 1)
                    local_t_a = norm * (len_a - 1) - idx_a_1
                    
                    val_a_1 = vals_a[idx_a_1]
                    val_a_2 = vals_a[idx_a_2]
                    
                    if val_a_1 is None or val_a_2 is None:
                        val_a_interp = None
                    else:
                        if hasattr(val_a_1, '__len__'):
                            val_a_interp = [val_a_1[j] + (val_a_2[j] - val_a_1[j]) * local_t_a for j in range(len(val_a_1))]
                        else:
                            val_a_interp = val_a_1 + (val_a_2 - val_a_1) * local_t_a
                else:
                    val_a_interp = vals_a[0]
                
                if len_b > 1:
                    idx_b_1 = int(norm * (len_b - 1))
                    idx_b_2 = min(idx_b_1 + 1, len_b - 1)
                    local_t_b = norm * (len_b - 1) - idx_b_1
                    
                    val_b_1 = vals_b[idx_b_1]
                    val_b_2 = vals_b[idx_b_2]
                    
                    if val_b_1 is None or val_b_2 is None:
                        val_b_interp = None
                    else:
                        if hasattr(val_b_1, '__len__'):
                            val_b_interp = [val_b_1[j] + (val_b_2[j] - val_b_1[j]) * local_t_b for j in range(len(val_b_1))]
                        else:
                            val_b_interp = val_b_1 + (val_b_2 - val_b_1) * local_t_b
                else:
                    val_b_interp = vals_b[0]
                
                # Skip if either value is None
                if val_a_interp is None or val_b_interp is None:
                    continue
                
                # Final interpolation between frame A and frame B
                try:
                    if hasattr(val_a_interp, '__len__') and hasattr(val_b_interp, '__len__'):
                        interp = [val_a_interp[j] * (1 - t) + val_b_interp[j] * t for j in range(len(val_a_interp))]
                        
                        if p_name == 'vector':
                            interp = Vector(interp)
                        elif p_name == 'color':
                            interp = tuple(interp)
                    else:
                        interp = val_a_interp * (1 - t) + val_b_interp * t
                    
                    setattr(attr.data[pt_offset + i], p_name, interp)
                except Exception as e:
                    pass

def _apply_curve_attrs_from_snapshots(dst, stroke_idx, snap_a, snap_b, t, drawing, attr_info):
    """Apply interpolated curve attributes to destination stroke."""
    for attr_name, info in attr_info.items():
        if info['domain'] == 'CURVE':
            attr = drawing.attributes.get(attr_name)
            if not attr:
                continue
            
            val_a = snap_a['curve_attrs'].get(attr_name)
            val_b = snap_b['curve_attrs'].get(attr_name)
            
            if val_a is None or val_b is None:
                continue
            
            p_name = info['p_name']
            
            try:
                # Interpolate curve attribute
                if hasattr(val_a, '__len__') and hasattr(val_b, '__len__'):
                    interp = []
                    for j in range(len(val_a)):
                        interp.append(val_a[j] * (1 - t) + val_b[j] * t)
                    
                    if p_name == 'vector':
                        interp = Vector(interp)
                    elif p_name == 'color':
                        interp = tuple(interp)
                else:
                    interp = val_a * (1 - t) + val_b * t
                
                setattr(attr.data[stroke_idx], p_name, interp)
            except Exception as e:
                pass

def _stepper_build_frame(obj, t, fn_temp, snapshots_a=None, snapshots_b=None, attr_info=None):
    """Build interpolated frame using pre-computed snapshots."""
    if not obj: 
        return False
    
    layer = obj.data.layers.active
    if not layer: 
        return False

    # If requesting one of the source frames, just show it
    if fn_temp == _ss.frame_num_a or fn_temp == _ss.frame_num_b:
        _ss.temp_frame_num = fn_temp
        _ss.t = t
        bpy.context.scene.frame_current = fn_temp
        return True

    # Quick exit if no snapshots
    if not snapshots_a or not snapshots_b:
        return False
    
    _ss.temp_frame_num = fn_temp
    _ss.t = t

    if not hasattr(_ss, 'temp_frame_nums') or _ss.temp_frame_nums is None:
        _ss.temp_frame_nums = set()
    _ss.temp_frame_nums.add(fn_temp)

    # Find or create target frame
    target_frame = None
    for fr in layer.frames:
        if fr.frame_number == fn_temp:
            target_frame = fr
            break
            
    if target_frame is None:
        try: 
            target_frame = layer.frames.new(fn_temp)
        except Exception as e: 
            print(f"Stepper error: {e}")
            return False

    drawing_new = _drawing_of_frame(target_frame)
    if not drawing_new: 
        return False
    
    # Clear existing strokes
    if len(drawing_new.strokes) > 0: 
        drawing_new.remove_strokes(indices=list(range(len(drawing_new.strokes))))

    # Create new strokes
    n = min(len(snapshots_a), len(snapshots_b))
    sizes = [len(snapshots_a[i]['positions']) for i in range(n)]
    
    if sizes:
        # --- CRITICAL FIX FOR BLENDER 5.0.1 (GPv3) ---
        # Recreate missing custom attributes (like colors) on the new frame before adding points
        if attr_info:
            for attr_name, info in attr_info.items():
                if attr_name not in drawing_new.attributes:
                    try:
                        drawing_new.attributes.new(name=attr_name, type=info['data_type'], domain=info['domain'])
                    except: pass
        
        drawing_new.add_strokes(sizes)
        
        # Calculate point offsets for all strokes in advance
        pt_offsets = [0]
        for i in range(len(sizes) - 1):
            pt_offsets.append(pt_offsets[-1] + sizes[i])
        
        for idx in range(n):
            snap_a = snapshots_a[idx]
            snap_b = snapshots_b[idx]
            new_s = drawing_new.strokes[idx]
            
            # Copy material index
            if hasattr(new_s, 'material_index'):
                try: 
                    new_s.material_index = snap_a['material_index']
                except: pass
            
            # Interpolate positions
            _interp_stroke_from_snapshots(snap_a, snap_b, new_s, t, attr_info or {})
            
            # Apply attributes with correct point offset
            if attr_info:
                _apply_point_attrs_to_stroke(new_s, snap_a, snap_b, t, attr_info, drawing_new, idx, pt_offsets[idx])
                _apply_curve_attrs_from_snapshots(new_s, idx, snap_a, snap_b, t, drawing_new, attr_info)
    
    obj.data.update_tag()
    bpy.context.scene.frame_current = fn_temp
    return True

def _stepper_update_frame(context):
    """Update the preview frame based on current stepper_frame property."""
    if not getattr(_ss, 'active', False): 
        return
    
    props = context.scene.stroke_organiser_props
    fn_a = _ss.frame_num_a
    fn_b = _ss.frame_num_b
    
    if props.stepper_frame <= fn_a: 
        props.stepper_frame = fn_a + 1
    
    fn_temp = props.stepper_frame
    t = (fn_temp - fn_a) / (fn_b - fn_a) if fn_b > fn_a else 0.5
    t = max(0.0, min(1.0, t))
    
    obj = bpy.data.objects.get(getattr(_ss, 'obj_name', ""))
    
    # Use pre-computed snapshots
    snapshots_a = getattr(_ss, 'snapshots_a', None)
    snapshots_b = getattr(_ss, 'snapshots_b', None)
    attr_info = getattr(_ss, 'attr_info', None)
    
    _stepper_build_frame(obj, t, fn_temp, snapshots_a, snapshots_b, attr_info)
    _redraw()

def _stepper_cleanup(delete_temp=True):
    """Clean up temporary frames and reset stepper state."""
    was_active = getattr(_ss, 'active', False)
    _ss.active = False
    
    obj_name = getattr(_ss, 'obj_name', "")
    obj = bpy.data.objects.get(obj_name) if obj_name else None
    
    fn_a = getattr(_ss, 'frame_num_a', None)
    fn_b = getattr(_ss, 'frame_num_b', None)
    temp_nums = getattr(_ss, 'temp_frame_nums', set())
    
    if delete_temp and obj and fn_a is not None:
        old_active = bpy.context.view_layer.objects.active
        bpy.context.view_layer.objects.active = obj
        
        layer = obj.data.layers.active
        if layer:
            for fn in list(temp_nums):
                if fn != fn_a and fn != fn_b:
                    bpy.context.scene.frame_current = fn
                    try:
                        bpy.ops.grease_pencil.delete_frame(type='ACTIVE_FRAME')
                    except:
                        try:
                            bpy.ops.gpencil.active_frames_delete_all()
                        except Exception as e:
                            print(f"Stepper Cleanup Error: {e}")
            
            obj.data.update_tag()
        
        bpy.context.scene.frame_current = fn_a
        if old_active:
            bpy.context.view_layer.objects.active = old_active

    # Reset state completely
    _ss.temp_frame_num = None
    if hasattr(_ss, 'temp_frame_nums'):
        _ss.temp_frame_nums = set()
    if hasattr(_ss, 'snapshots_a'):
        _ss.snapshots_a = None
    if hasattr(_ss, 'snapshots_b'):
        _ss.snapshots_b = None
    if hasattr(_ss, 'attr_info'):
        _ss.attr_info = None

class SO_OT_stepper_start(bpy.types.Operator):
    bl_idname = "stroke_organiser.stepper_start"
    bl_label = "Démarrer Interpolation Stepper"
    bl_description = "Génère un ou plusieurs in-betweens dynamiques contrôlés."
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        from .utils import _as, _rs
        obj = _gp_obj(context)
        return (obj and not getattr(_ss, 'active', False) and not getattr(_as, 'active', False) and not getattr(_rs, 'active', False))

    def execute(self, context):
        obj = _gp_obj(context)
        fa = obj.data.layers.active.current_frame() if (obj and obj.data.layers.active) else None
        fb = _next_frame(obj)
        
        if fa is None or fb is None:
            self.report({'WARNING'}, "Clé de départ ou clé suivante introuvable.")
            return {'CANCELLED'}
        
        # Get drawings and create snapshots
        drawing_a = _drawing_of_frame(fa)
        drawing_b = _drawing_of_frame(fb)
        
        if not drawing_a or not drawing_b:
            self.report({'WARNING'}, "Drawing inaccessible.")
            return {'CANCELLED'}
        
        # Pre-compute all snapshots at startup (major optimization)
        snapshots_a = []
        snapshots_b = []
        attr_info = {}
        
        # --- FIX: Extract and save 'data_type' to allow recreating attributes later ---
        for attr in drawing_a.attributes:
            p_name = 'vector' if attr.data_type in {'FLOAT_VECTOR', 'FLOAT2'} else ('color' if attr.data_type in {'FLOAT_COLOR', 'BYTE_COLOR'} else 'value')
            attr_info[attr.name] = {
                'domain': attr.domain, 
                'p_name': p_name,
                'data_type': attr.data_type
            }
        
        # Create snapshots for all strokes
        for idx, stroke in enumerate(drawing_a.strokes):
            snapshots_a.append(_create_stroke_snapshot(stroke, drawing_a, idx))
        
        for idx, stroke in enumerate(drawing_b.strokes):
            snapshots_b.append(_create_stroke_snapshot(stroke, drawing_b, idx))
        
        # Initialize stepper state
        _ss.active = True
        _ss.obj_name = obj.name
        _ss.frame_num_a = fa.frame_number
        _ss.frame_num_b = fb.frame_number
        _ss.temp_frame_num = None
        _ss.temp_frame_nums = set()
        _ss.snapshots_a = snapshots_a
        _ss.snapshots_b = snapshots_b
        _ss.attr_info = attr_info

        cp = context.scene.frame_current
        initial_frame = cp if fa.frame_number < cp < fb.frame_number else fa.frame_number + 1
        props = context.scene.stroke_organiser_props
        props.stepper_frame = initial_frame
        t = (initial_frame - fa.frame_number) / (fb.frame_number - fa.frame_number) if fb.frame_number > fa.frame_number else 0.5
        
        if not _stepper_build_frame(obj, t, initial_frame, snapshots_a, snapshots_b, attr_info):
            _ss.active = False
            return {'CANCELLED'}
        
        context.window_manager.modal_handler_add(self)
        _redraw()
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if not getattr(_ss, 'active', False): 
            _redraw()
            return {'FINISHED'}
            
        if event.type == 'ESC' and event.value == 'PRESS':
            _stepper_cleanup(delete_temp=True)
            _redraw()
            self.report({'INFO'}, "Stepper annulé, toutes les frames temporaires ont été retirées.")
            return {'CANCELLED'}
            
        if event.type == 'LEFT_ARROW' and event.value == 'PRESS':
            props = context.scene.stroke_organiser_props
            props.stepper_frame = max(_ss.frame_num_a + 1, props.stepper_frame - 1)
            _redraw()
            return {'RUNNING_MODAL'}
            
        if event.type == 'RIGHT_ARROW' and event.value == 'PRESS':
            props = context.scene.stroke_organiser_props
            props.stepper_frame = min(_ss.frame_num_b - 1, props.stepper_frame + 1)
            _redraw()
            return {'RUNNING_MODAL'}
            
        return {'PASS_THROUGH'}

class SO_OT_stepper_insert(bpy.types.Operator):
    bl_idname = "stroke_organiser.stepper_insert"
    bl_label = "Insérer la(les) frame(s)"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context): 
        return getattr(_ss, 'active', False) or len(getattr(_ss, 'temp_frame_nums', set())) > 0
        
    def execute(self, context):
        _stepper_cleanup(delete_temp=False)
        bpy.ops.ed.undo_push(message="Génération In-betweens (Stepper)")
        _redraw()
        self.report({'INFO'}, "Toutes les frames créées ont été validées et fixées.")
        return {'FINISHED'}

class SO_OT_stepper_cancel(bpy.types.Operator):
    bl_idname = "stroke_organiser.stepper_cancel"
    bl_label = "Annuler Stepper"
    bl_options = {'REGISTER', 'UNDO'}
    
    @classmethod
    def poll(cls, context): 
        return getattr(_ss, 'active', False) or len(getattr(_ss, 'temp_frame_nums', set())) > 0
    
    def execute(self, context): 
        _stepper_cleanup(delete_temp=True)
        _redraw()
        return {'FINISHED'}

class SO_OT_copy_from_neighbor(bpy.types.Operator):
    bl_idname = "stroke_organiser.copy_from_neighbor"
    bl_label = "Copier depuis frame voisine"
    bl_options = {'REGISTER', 'UNDO'}
    direction: bpy.props.EnumProperty(name="Direction", items=[('PREV', "← Précédente", ""), ('NEXT', "→ Suivante", "")], default='PREV')

    @classmethod
    def poll(cls, context):
        from .utils import _as
        obj = _gp_obj(context)
        return obj and context.mode in {'EDIT_GREASE_PENCIL', 'EDIT'} and not getattr(_as, 'active', False)

    def execute(self, context):
        obj = _gp_obj(context)
        from .utils import _find_selected_stroke, _get_strokes
        si = _find_selected_stroke(obj)
        if si == -1: 
            return {'CANCELLED'}
        
        neighbor = _prev_frame(obj) if self.direction == 'PREV' else _next_frame(obj)
        if neighbor is None: 
            return {'CANCELLED'}
        
        src_d = _drawing_of_frame(neighbor)
        if src_d is None or si >= len(src_d.strokes): 
            return {'CANCELLED'}
        
        src = src_d.strokes[si]
        if len(src.points) == 0: 
            return {'CANCELLED'}
        
        dst_s = _get_strokes(obj)
        if not dst_s or si >= len(dst_s): 
            return {'CANCELLED'}
        
        _copy_geometry(src, dst_s[si])
        obj.data.update_tag()
        _redraw()
        return {'FINISHED'}